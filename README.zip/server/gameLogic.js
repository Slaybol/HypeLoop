// server/gameLogic.js
const roomManager = require("./roomManager");
const { getPrompt } = require("./promptService");
const { getLeaderboard } = require("./leaderboard"); // Assuming you have this file
const { applyChaosMode } = require("./chaos"); // Assuming you have this file

const gameLogic = {
  startGame: (io, roomId, roomState) => {
    if (!roomState) return;

    roomState.round = 1;
    roomState.currentPhase = "answering";
    roomState.answers = [];
    roomState.votes = {};
    roomState.currentPrompt = getPrompt(roomState.theme.name);

    roomManager.updateRoomState(roomId, roomState);
    io.to(roomId).emit("game-started", {
      prompt: roomState.currentPrompt,
      players: Object.values(roomState.players),
      round: roomState.round,
      phase: roomState.currentPhase,
    });
    console.log(`Game started in room ${roomId}. Round 1, Phase: Answering.`);
  },

  submitAnswer: (io, playerId, roomId, answerText) => {
    const roomState = roomManager.getRoom(roomId);
    if (!roomState || roomState.currentPhase !== "answering") return;

    // Check if player has already answered
    const existingAnswer = roomState.answers.find(a => a.playerId === playerId);
    if (existingAnswer) {
      existingAnswer.text = answerText; // Allow updating answer
    } else {
      roomState.answers.push({ playerId, text: answerText });
    }

    roomManager.updateRoomState(roomId, roomState);
    io.to(roomId).emit("answer-submitted", { playerId, answerText }); // Notify all
    console.log(`Player ${playerId} submitted answer in room ${roomId}.`);
  },

  transitionToVoting: (io, roomId) => {
    const roomState = roomManager.getRoom(roomId);
    if (!roomState) return;

    roomState.currentPhase = "voting";
    roomState.votes = {}; // Reset votes for new phase

    roomManager.updateRoomState(roomId, roomState);
    io.to(roomId).emit("voting-phase", {
      answers: roomState.answers,
      phase: roomState.currentPhase,
    });
    console.log(`Transitioned to voting phase in room ${roomId}.`);
  },

  submitVote: (io, voterId, roomId, votedPlayerId) => {
    const roomState = roomManager.getRoom(roomId);
    if (!roomState || roomState.currentPhase !== "voting") return;

    // Prevent self-voting and multiple votes from one player
    if (voterId === votedPlayerId) {
      // Optionally send an error to the voter
      io.to(voterId).emit("vote-error", "Cannot vote for yourself.");
      return;
    }
    if (roomState.votes[voterId]) { // If voter has already voted
      // Optionally change vote or send error
      io.to(voterId).emit("vote-error", "You have already voted.");
      return;
    }

    roomState.votes[voterId] = votedPlayerId; // Store who voted for whom
    // Increment score for the voted player temporarily to show progress
    // Actual score update happens after all votes are counted or phase ends
    // For simplicity, we just store the vote and count later.

    roomManager.updateRoomState(roomId, roomState);
    io.to(roomId).emit("vote-submitted", { voterId, votedPlayerId }); // Could hide who voted for whom
    console.log(`Player ${voterId} voted for ${votedPlayerId} in room ${roomId}.`);

    // Check if all active players (those who answered) have voted
    const playersWhoAnswered = roomState.answers.map(a => a.playerId);
    const uniqueVoters = new Set(Object.keys(roomState.votes));

    if (playersWhoAnswered.every(pId => uniqueVoters.has(pId))) {
       // All players who answered have voted, automatically transition
       gameLogic.transitionToResults(io, roomId);
    }
  },

  transitionToResults: (io, roomId) => {
    const roomState = roomManager.getRoom(roomId);
    if (!roomState) return;

    roomState.currentPhase = "results";
    let roundWinner = null;
    let maxVotes = 0;
    const playerScoresThisRound = {};

    // Count votes and update scores
    for (const voterId in roomState.votes) {
      const votedPlayerId = roomState.votes[voterId];
      playerScoresThisRound[votedPlayerId] = (playerScoresThisRound[votedPlayerId] || 0) + 1;
    }

    for (const playerId in playerScoresThisRound) {
      const scoreToAdd = playerScoresThisRound[playerId];
      if (roomState.players[playerId]) {
        roomState.players[playerId].score += scoreToAdd; // Add to total score
      }
      if (scoreToAdd > maxVotes) {
        maxVotes = scoreToAdd;
        roundWinner = roomState.players[playerId];
      }
    }

    // Apply chaos mode if active
    if (roomState.chaos) {
      roomState.players = applyChaosMode(roomState.players, roomState.chaos); // chaos.js should modify player scores/states
      console.log(`Chaos mode '${roomState.chaos}' applied in room ${roomId}.`);
    }

    // Get updated leaderboard
    const leaderboard = getLeaderboard(Object.values(roomState.players));

    roomManager.updateRoomState(roomId, roomState);
    io.to(roomId).emit("round-results", {
      roundWinner: roundWinner,
      leaderboard: leaderboard,
      phase: roomState.currentPhase,
      playerScoresThisRound: playerScoresThisRound, // show how many votes each got this round
    });
    console.log(`Transitioned to results phase in room ${roomId}. Winner: ${roundWinner ? roundWinner.name : 'No winner'}.`);
  },

  startNextRound: (io, roomId) => {
    const roomState = roomManager.getRoom(roomId);
    if (!roomState) return;

    roomState.round += 1;
    roomState.currentPhase = "answering";
    roomState.answers = [];
    roomState.votes = {}; // Reset votes for new round
    roomState.currentPrompt = getPrompt(roomState.theme.name); // Get new prompt
    roomState.chaos = null; // Reset chaos for new round, apply based on rules later

    roomManager.updateRoomState(roomId, roomState);
    io.to(roomId).emit("game-started", { // Re-using game-started event for new round
      prompt: roomState.currentPrompt,
      players: Object.values(roomState.players),
      round: roomState.round,
      phase: roomState.currentPhase,
    });
    console.log(`Starting round ${roomState.round} in room ${roomId}. Phase: Answering.`);
  },
};

module.exports = gameLogic;