// server/promptService.js
// Hardcoded fallback prompts for now
const fallbackPrompts = {
  "1990s": [
    "Invent a wild new Nickelodeon game show.",
    "What's in your Y2K bug-out bag?",
    "Describe your dream 90s toy mashup.",
  ],
  "sci-fi": [
    "Describe a malfunctioning AI assistant.",
    "Name a new alien species and their favorite food.",
    "Pitch a bad sci-fi sequel.",
  ],
  "adult": [
    "Write a terrible Tinder bio.",
    "Invent a new adult party game.",
    "Describe an awkward Zoom call.",
  ],
  "general": [
    "Invent a new holiday tradition.",
    "Describe a bizarre new animal.",
    "What's the worst superpower to have?",
  ]
};

// Placeholder for OpenAI integration
// const openaiService = require('./openaiService');

function getPrompt(themeName = "general") {
  const prompts = fallbackPrompts[themeName] || fallbackPrompts["general"];
  const selectedPrompt = prompts[Math.floor(Math.random() * prompts.length)];

  // In the future, this is where you'd call OpenAI
  // try {
  //   const aiPrompt = await openaiService.generatePrompt(themeName);
  //   return aiPrompt; // Or combine with fallback for variety
  // } catch (error) {
  //   console.error("Error generating AI prompt:", error);
  //   return selectedPrompt; // Fallback to a hardcoded prompt
  // }

  return selectedPrompt;
}

module.exports = { getPrompt };