require('dotenv').config(); // Load environment variables from .env file
const express = require("express");
const http = require("http");
const { Server } = require("socket.io");
const cors = require("cors");
const bodyParser = require("body-parser");

// Import modularized server logic
const { getPrompt } = require("./promptService");
const { applyChaosMode } = require("./chaos");
const { initTwitchVoting } = require("./twitch");
const { getLeaderboard } = require("./leaderboard"); // Assuming you also have a leaderboard.js
const roomManager = require("./roomManager"); // Use roomManager.js for room state management
const gameLogic = require("./gameLogic"); // Use gameLogic.js for game phase transitions

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: process.env.CLIENT_URL || "http://localhost:5173", // Use environment variable for client URL
    methods: ["GET", "POST"],
  },
});

app.use(cors());
app.use(express.static("public")); // If you serve any static files from the server
app.use(bodyParser.json());

// Server health check endpoint
app.get("/health", (req, res) => {
  res.status(200).send("Server is healthy");
});

io.on("connection", (socket) => {
  console.log(`User connected: ${socket.id}`);

  // Initialize Twitch voting for the connected socket, if applicable
  initTwitchVoting(socket); // Pass socket, not room yet, as room is determined later

  socket.on("join-room", ({ name, room, theme }) => {
    // Ensure room and name are provided
    if (!room || !name) {
      socket.emit("join-error", "Room name and player name are required.");
      return;
    }

    // Try to join the room
    const { success, message, roomState } = roomManager.joinRoom(socket.id, name, room, theme);

    if (success) {
      socket.join(room); // Join the socket.io room
      io.to(room).emit("room-updated", roomState); // Notify everyone in the room
      socket.emit("join-success", { room, name, roomState }); // Confirm to the joining player

      console.log(`${name} joined room: ${room}`);
      // If this is the first player, or a specific condition, start the game
      if (Object.keys(roomState.players).length === 1) {
        // Optionally start game automatically or wait for host
        // gameLogic.startGame(io, room, roomState);
      }
    } else {
      socket.emit("join-error", message);
    }
  });

  socket.on("start-game", ({ room }) => {
    const roomState = roomManager.getRoom(room);
    if (roomState && Object.keys(roomState.players).length >= 1) { // Minimum 1 player to start
      gameLogic.startGame(io, room, roomState);
    } else {
      socket.emit("game-start-error", "Cannot start game: Room not found or not enough players.");
    }
  });

  socket.on("submit-answer", ({ room, answer }) => {
    const roomState = roomManager.getRoom(room);
    if (roomState && roomState.currentPhase === "answering") {
      gameLogic.submitAnswer(io, socket.id, room, answer);
    }
  });

  socket.on("end-answer-phase", ({ room }) => {
    const roomState = roomManager.getRoom(room);
    if (roomState && roomState.currentPhase === "answering") {
      gameLogic.transitionToVoting(io, room);
    }
  });

  socket.on("submit-vote", ({ room, votedPlayerId }) => {
    const roomState = roomManager.getRoom(room);
    if (roomState && roomState.currentPhase === "voting") {
      gameLogic.submitVote(io, socket.id, room, votedPlayerId);
    }
  });

  socket.on("end-voting-phase", ({ room }) => {
    const roomState = roomManager.getRoom(room);
    if (roomState && roomState.currentPhase === "voting") {
      gameLogic.transitionToResults(io, room);
    }
  });

  socket.on("next-round", ({ room }) => {
    const roomState = roomManager.getRoom(room);
    if (roomState) {
      gameLogic.startNextRound(io, room);
    }
  });

  socket.on("get-leaderboard", ({ room }) => {
    const roomState = roomManager.getRoom(room);
    if (roomState) {
      const leaderboard = getLeaderboard(Object.values(roomState.players));
      socket.emit("leaderboard-data", leaderboard);
    }
  });

  socket.on("disconnect", () => {
    console.log(`User disconnected: ${socket.id}`);
    // Handle player leaving all rooms they were in
    roomManager.handleDisconnect(socket.id, io);
  });
});

const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});