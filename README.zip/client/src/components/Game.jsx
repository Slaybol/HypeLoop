// client/src/components/Game.jsx
import React, { useState, useEffect } from 'react';
import socket from '../socket'; // Assuming socket.js is in client/src/
import { startVoiceInput } from '../voice'; // Assuming voice.js is in client/src/
import '../App.css'; // Assuming App.css contains your main styling

function Game() {
  const [name, setName] = useState('');
  const [room, setRoom] = useState('');
  const [theme, setTheme] = useState('general'); // Default theme
  const [roomState, setRoomState] = useState(null); // Full room state from server
  const [error, setError] = useState('');
  const [answerText, setAnswerText] = useState('');

  useEffect(() => {
    socket.on('join-success', ({ room, name, roomState: initialRoomState }) => {
      console.log(`Successfully joined room: ${room}, as ${name}`);
      setRoomState(initialRoomState);
      setError(''); // Clear any previous errors
    });

    socket.on('join-error', (message) => {
      setError(message);
      setRoomState(null); // Clear room state on error
    });

    socket.on('room-updated', (updatedRoomState) => {
      console.log('Room state updated:', updatedRoomState);
      setRoomState(updatedRoomState);
    });

    socket.on('game-started', (data) => {
      console.log('Game started:', data);
      setRoomState(prev => ({ ...prev, currentPrompt: data.prompt, currentPhase: data.phase, round: data.round }));
      setAnswerText(''); // Clear answer field for new round
    });

    socket.on('answer-submitted', (data) => {
      console.log('Answer submitted by:', data.playerId);
      // Update local state if needed to show answers
      setRoomState(prev => {
        const newAnswers = prev.answers.some(a => a.playerId === data.playerId)
          ? prev.answers.map(a => a.playerId === data.playerId ? { ...a, text: data.answerText } : a)
          : [...prev.answers, { playerId: data.playerId, text: data.answerText }];
        return { ...prev, answers: newAnswers };
      });
    });

    socket.on('voting-phase', (data) => {
      console.log('Transitioned to voting phase. Answers:', data.answers);
      setRoomState(prev => ({ ...prev, currentPhase: data.phase, answers: data.answers }));
    });

    socket.on('vote-submitted', (data) => {
      console.log(`Player ${data.voterId} voted for ${data.votedPlayerId}`);
      // You might want to update a local state to show who has voted
    });

    socket.on('round-results', (data) => {
      console.log('Round results:', data);
      setRoomState(prev => ({ ...prev, currentPhase: data.phase, players: Object.fromEntries(data.leaderboard.map(p => [p.id, p])) }));
    });

    socket.on('leaderboard-data', (leaderboard) => {
      console.log('Leaderboard updated:', leaderboard);
      // You might update a dedicated leaderboard state or the main players state
      setRoomState(prev => ({ ...prev, players: Object.fromEntries(leaderboard.map(p => [p.id, p])) }));
    });

    return () => {
      socket.off('join-success');
      socket.off('join-error');
      socket.off('room-updated');
      socket.off('game-started');
      socket.off('answer-submitted');
      socket.off('voting-phase');
      socket.off('vote-submitted');
      socket.off('round-results');
      socket.off('leaderboard-data');
    };
  }, []);

  const handleJoinRoom = () => {
    if (name && room) {
      socket.emit('join-room', { name, room, theme });
    } else {
      setError('Please enter your name and a room name.');
    }
  };

  const handleStartGame = () => {
    if (roomState && roomState.id) {
      socket.emit('start-game', { room: roomState.id });
    }
  };

  const handleSubmitAnswer = () => {
    if (roomState && roomState.id && answerText) {
      socket.emit('submit-answer', { room: roomState.id, answer: answerText });
      setAnswerText(''); // Clear input after submitting
    } else {
      setError('Please enter an answer.');
    }
  };

  const handleEndAnswerPhase = () => {
    if (roomState && roomState.id) {
      socket.emit('end-answer-phase', { room: roomState.id });
    }
  };

  const handleSubmitVote = (votedPlayerId) => {
    if (roomState && roomState.id && votedPlayerId) {
      socket.emit('submit-vote', { room: roomState.id, votedPlayerId });
    }
  };

  const handleEndVotingPhase = () => {
    if (roomState && roomState.id) {
      socket.emit('end-voting-phase', { room: roomState.id });
    }
  };

  const handleNextRound = () => {
    if (roomState && roomState.id) {
      socket.emit('next-round', { room: roomState.id });
    }
  };

  // Voice input handler
  const handleVoiceInput = () => {
    startVoiceInput(setAnswerText);
  };

  if (!roomState) {
    return (
      <div className="join-screen">
        <h1>HypeLoop</h1>
        <input
          type="text"
          placeholder="Your Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <input
          type="text"
          placeholder="Room Name"
          value={room}
          onChange={(e) => setRoom(e.target.value)}
        />
        <select value={theme} onChange={(e) => setTheme(e.target.value)}>
          <option value="general">General</option>
          <option value="1990s">1990s</option>
          <option value="sci-fi">Sci-Fi</option>
          <option value="adult">Adult</option>
        </select>
        <button onClick={handleJoinRoom}>Join Room</button>
        {error && <p className="error">{error}</p>}
      </div>
    );
  }

  const playersArray = Object.values(roomState.players || {});
  const host = playersArray.find(p => p.id === roomState.hostId);
  const isHost = socket.id === roomState.hostId;

  return (
    <div className="game-screen">
      <h1>HypeLoop - Room: {roomState.id}</h1>
      <p>Theme: {roomState.theme.name}</p>
      {roomState.round > 0 && <p>Round: {roomState.round}</p>}

      <div className="players">
        {playersArray.map((player) => (
          <div key={player.id} className="player">
            <img src={player.avatar} alt={player.name} />
            <p>{player.name} {player.id === socket.id ? '(You)' : ''} {player.id === roomState.hostId ? '(Host)' : ''}</p>
            <p>Score: {player.score}</p>
          </div>
        ))}
      </div>

      {roomState.currentPhase === 'waiting' && (
        <div>
          <p>Waiting for players...</p>
          {isHost && playersArray.length >= 1 && ( // Host can start with 1 player for testing
            <button onClick={handleStartGame}>Start Game</button>
          )}
        </div>
      )}

      {roomState.currentPhase === 'answering' && (
        <div>
          <h2>Prompt: {roomState.currentPrompt}</h2>
          <textarea
            placeholder="Your answer..."
            value={answerText}
            onChange={(e) => setAnswerText(e.target.value)}
          ></textarea>
          <button onClick={handleSubmitAnswer}>Submit Answer</button>
          <button onClick={handleVoiceInput}>Voice Input</button>
          {isHost && (
            <button onClick={handleEndAnswerPhase}>End Answering Phase (Host)</button>
          )}
          <h3>Answers Submitted:</h3>
          <ul>
            {roomState.answers.map(ans => (
              <li key={ans.playerId}>
                {roomState.players[ans.playerId]?.name}: {ans.text}
              </li>
            ))}
          </ul>
        </div>
      )}

      {roomState.currentPhase === 'voting' && (
        <div>
          <h2>Vote for your favorite answer!</h2>
          <div className="answers-to-vote">
            {roomState.answers.map((answer) => (
              <div key={answer.playerId} className="answer-card">
                <p>{roomState.players[answer.playerId]?.name}: {answer.text}</p>
                <button onClick={() => handleSubmitVote(answer.playerId)}
                        disabled={socket.id === answer.playerId || roomState.votes[socket.id]}>
                  Vote for {roomState.players[answer.playerId]?.name}
                </button>
              </div>
            ))}
          </div>
          {isHost && (
            <button onClick={handleEndVotingPhase}>End Voting Phase (Host)</button>
          )}
        </div>
      )}

      {roomState.currentPhase === 'results' && (
        <div>
          <h2>Round Results!</h2>
          {roomState.roundWinner && (
            <h3>Winner of the round: {roomState.roundWinner.name}!</h3>
          )}
          <h4>Votes this round:</h4>
          <ul>
            {Object.entries(roomState.playerScoresThisRound || {}).map(([playerId, votes]) => (
              <li key={playerId}>{roomState.players[playerId]?.name}: {votes} votes</li>
            ))}
          </ul>

          <h4>Overall Leaderboard:</h4>
          <ul>
            {playersArray.sort((a, b) => b.score - a.score).map(player => (
              <li key={player.id}>{player.name}: {player.score} points</li>
            ))}
          </ul>

          {isHost && (
            <button onClick={handleNextRound}>Next Round</button>
          )}
        </div>
      )}
    </div>
  );
}

export default Game;