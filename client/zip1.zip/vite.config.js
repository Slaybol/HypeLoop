
export default {
  server: {
    host: true,
    port: 5173
  }
}
